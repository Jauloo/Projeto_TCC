using UnityEngine;
using TMPro;

public class SceneInitializer : MonoBehaviour
{

    public GameObject portalUnix;
    public GameObject portalBSD;
    public GameObject portalLinux;
    public GameObject portalDebian;
    public GameObject portalUbuntu;
    public GameObject portalAndroid;
    public GameObject portalRedox;
    public GameObject portalAtualmente;
    
    public GameObject portalFinal;  

    public GameObject endDialoguePanel;          
    public TextMeshProUGUI endDialogueText;  

    void Start()
    {
        AtualizarPortais();

        Time.timeScale = 1f;

        var player = GameObject.FindWithTag("Player");
        if (player != null)
        {
            var pm = player.GetComponent<PlayerMovement>();
            if (pm != null)
            {
                pm.canMove = true;
                pm.enabled = true;
            }

            var rb = player.GetComponent<Rigidbody2D>();
            if (rb != null) rb.simulated = true;
        }
    }

    public void AtualizarPortais()
    {
        if (portalUnix != null)
            portalUnix.SetActive(!GameState.UnixCompleted);

        if (portalBSD != null)
            portalBSD.SetActive(GameState.UnixCompleted && !GameState.BSDCompleted);

        if (portalLinux != null)
            portalLinux.SetActive(GameState.BSDCompleted && !GameState.LinuxCompleted);

        if (portalDebian != null)
            portalDebian.SetActive(GameState.LinuxCompleted && !GameState.DebianCompleted);

        if (portalUbuntu != null)
            portalUbuntu.SetActive(GameState.DebianCompleted && !GameState.UbuntuCompleted);

        if (portalAndroid != null)
            portalAndroid.SetActive(GameState.UbuntuCompleted && !GameState.AndroidCompleted);

        if (portalRedox != null)
            portalRedox.SetActive(GameState.AndroidCompleted && !GameState.RedoxOSCompleted);
            
        if (portalAtualmente != null)
            portalAtualmente.SetActive(GameState.RedoxOSCompleted && !GameState.AtualmenteCompleted);

        if (GameState.AtualmenteCompleted)
        {
            MostrarMensagemFinal();
        }
        else
        {
            if (endDialoguePanel != null) endDialoguePanel.SetActive(false);
            if (portalFinal != null) portalFinal.SetActive(false);
        }        
    }

    void MostrarMensagemFinal()
    {
        if (endDialoguePanel != null)
        {
            endDialoguePanel.SetActive(true);

            if (endDialogueText != null)
            {
                endDialogueText.text = "Parabéns! Você completou a jornada pelos sistemas operacionais open source.\n\n Obrigado por jogar, siga estudando e compartilhando conhecimento!";
            }
        }

        if (portalFinal != null)
        {
            portalFinal.SetActive(true);
        }
    }

}
