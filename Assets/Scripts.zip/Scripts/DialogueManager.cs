using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class DialogueManager : MonoBehaviour
{
    public GameObject dialoguePanel;
    public TextMeshProUGUI dialogueText;

    public GameObject optionButtonsPanel;

    public string[] dialogueLines;
    private int index;

    public float typingSpeed = 0.005f;
    private bool isTyping = false;

    public PlayerMovement playerMovement;

    public GameObject portalToMain;

    void Start()
    {
        dialoguePanel.SetActive(true);
        optionButtonsPanel.SetActive(false);
        playerMovement.enabled = false;

        StartCoroutine(TypeLine());
    }

    void Update()
    {
        if (!isTyping && index < dialogueLines.Length && Input.GetKeyDown(KeyCode.Space))
        {
            index++;
            if (index < dialogueLines.Length)
            {
                dialogueText.text = "";
                StartCoroutine(TypeLine());
            }
            else
            {
                ShowOptions();
            }
        }
    }

    IEnumerator TypeLine()
    {
        isTyping = true;
        foreach (char letter in dialogueLines[index].ToCharArray())
        {
            dialogueText.text += letter;
            yield return new WaitForSeconds(typingSpeed);
        }
        isTyping = false;
    }

    void ShowOptions()
    {
        optionButtonsPanel.SetActive(true);
    }

    public void ContinueMission()
    {
        if (playerMovement != null)
        {
            playerMovement.enabled = true;
            playerMovement.canMove = true;
        }

        var player = GameObject.FindWithTag("Player");
        if (player != null)
        {
            var rb = player.GetComponent<Rigidbody2D>();
            if (rb != null) rb.simulated = true;
        }

        if (portalToMain != null)
        {
            portalToMain.SetActive(true);
            Debug.Log("portal active after set: " + portalToMain.activeSelf);
            Debug.Log("portal pos: " + portalToMain.transform.position);
        }

        Time.timeScale = 1f;
        dialoguePanel.SetActive(false);
        optionButtonsPanel.SetActive(false);
    }

    public void ExplainOpenSource()
    {
        dialogueText.text = "Sistemas Operacionais Open Source são softwares cujo código fonte é aberto para qualquer pessoa estudar, modificar e distribuir. Eles promovem colaboração, liberdade e evolução tecnológica.\n\nPressione espaço…";
        index = -1; 
        optionButtonsPanel.SetActive(false);
    }

    public void ExitGame()
    {
        SceneManager.LoadScene("EndScene");
    }
}
